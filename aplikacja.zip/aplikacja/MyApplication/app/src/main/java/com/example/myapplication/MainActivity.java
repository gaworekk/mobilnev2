package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button buttonDisable;
    private Button reset;
    private TextView licznik;
    private int liczba=0;
    @Override
    protected void  onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_main);

        buttonDisable=findViewById(R.id.buttonDisable);
        licznik=findViewById(R.id.licznik);


        buttonDisable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonDisable.setEnabled(false);
                liczba++;
                licznik.setText("przycisk kkliknmięto: "+liczba);
                Toast.makeText(MainActivity.this,"Przycisk zostal klikniety",Toast.LENGTH_SHORT).show();
            }
        });
        reset=findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                buttonDisable.setEnabled(true);
            }
        });
    }

}